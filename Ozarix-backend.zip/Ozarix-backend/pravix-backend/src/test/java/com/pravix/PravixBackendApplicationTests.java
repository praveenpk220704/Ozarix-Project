package com.pravix;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PravixBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
