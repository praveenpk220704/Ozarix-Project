package com.pravix.service;

import com.pravix.entity.ServiceEntity;
import com.pravix.repository.ServiceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ServiceService {

    @Autowired
    private ServiceRepository repository;

    // Create Service
    public ServiceEntity addService(ServiceEntity service) {
        return repository.save(service);
    }

    // Get All Services
    public List<ServiceEntity> getAllServices() {
        return repository.findAll();
    }

    // Get Service By Id
    public ServiceEntity getServiceById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Service not found"));
    }

    // Update Service
    public ServiceEntity updateService(Long id, ServiceEntity updatedService) {

        ServiceEntity service = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Service not found"));

        service.setServiceName(updatedService.getServiceName());
        service.setDescription(updatedService.getDescription());
        service.setIcon(updatedService.getIcon());
        service.setActive(updatedService.isActive());

        return repository.save(service);
    }

    // Delete Service
    public String deleteService(Long id) {

        if (!repository.existsById(id)) {
            throw new RuntimeException("Service not found");
        }

        repository.deleteById(id);

        return "Service deleted successfully";
    }
}