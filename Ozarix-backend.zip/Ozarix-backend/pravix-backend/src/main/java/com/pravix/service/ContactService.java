package com.pravix.service;

import com.pravix.entity.Contact;
import com.pravix.repository.ContactRepository;
import com.pravix.util.EmailTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ContactService {

    @Autowired
    private ContactRepository repository;

    @Autowired
    private EmailService emailService;

    @Value("${spring.mail.username}")
    private String companyEmail;

    // Save Contact
    public Contact saveContact(Contact contact) {

        // Save in Database
        Contact savedContact = repository.save(contact);

        // ===============================
        // Email to Customer
        // ===============================

        emailService.sendHtmlEmail(
                contact.getEmail(),
                "Thank You for Contacting Pravix Technologies",
                EmailTemplate.customerContactTemplate(
                        contact.getName()
                )
        );

        // ===============================
        // Email to Company
        // ===============================

        emailService.sendHtmlEmail(
                companyEmail,
                "🔔 New Contact Request Received",
                EmailTemplate.adminContactTemplate(contact)
        );

        return savedContact;
    }

    // Get All Contacts
    public List<Contact> getAllContacts() {
        return repository.findAll();
    }

    // Delete Contact
    public String deleteContact(Long id) {

        Contact contact = repository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Contact Not Found"));

        repository.delete(contact);

        return "Contact Deleted Successfully";
    }

    public Contact getContactById(Long id) {

        return repository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Contact Not Found"));
    }

    // Update Contact
    public Contact updateContact(Long id,
                                 Contact updatedContact) {

        Contact contact = getContactById(id);

        contact.setName(updatedContact.getName());
        contact.setEmail(updatedContact.getEmail());
        contact.setPhone(updatedContact.getPhone());
        contact.setService(updatedContact.getService());
        contact.setMessage(updatedContact.getMessage());

        return repository.save(contact);
    }
}