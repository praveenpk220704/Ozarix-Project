package com.pravix.service;

import com.pravix.entity.Team;
import com.pravix.exception.ResourceNotFoundException;
import com.pravix.repository.TeamRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TeamService {

    @Autowired
    private TeamRepository repository;

    // Create Team Member
    public Team saveTeam(Team team) {
        return repository.save(team);
    }

    // Get All Team Members
    public List<Team> getAllTeams() {
        return repository.findAll();
    }

    public Team getTeamById(Long id) {
        return repository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Team Member Not Found"));
    }

    // Update Team Member
    public Team updateTeam(Long id, Team updatedTeam) {

        Team team = getTeamById(id);

        team.setName(updatedTeam.getName());
        team.setRole(updatedTeam.getRole());
        team.setExperience(updatedTeam.getExperience());
        team.setSkills(updatedTeam.getSkills());
        team.setImage(updatedTeam.getImage());
        team.setLinkedin(updatedTeam.getLinkedin());
        team.setGithub(updatedTeam.getGithub());

        return repository.save(team);
    }

    // Delete Team Member
    public String deleteTeam(Long id) {

        Team team = getTeamById(id);

        repository.delete(team);

        return "Team Member Deleted Successfully";
    }
}