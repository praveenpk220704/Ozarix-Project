package com.pravix.Controller;

import com.pravix.entity.Team;
import com.pravix.service.TeamService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/team")
@CrossOrigin("*")
public class TeamController {

    @Autowired
    private TeamService service;

    // =========================
    // PUBLIC - View Team
    // =========================

    @GetMapping
    public List<Team> getAllTeams() {
        return service.getAllTeams();
    }

    @GetMapping("/{id}")
    public Team getTeamById(@PathVariable Long id) {
        return service.getTeamById(id);
    }

    // =========================
    // ADMIN - Add Team Member
    // =========================

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping
    public Team saveTeam(@Valid @RequestBody Team team) {
        return service.saveTeam(team);
    }

    // =========================
    // ADMIN - Update Team Member
    // =========================

    @PreAuthorize("hasRole('ADMIN')")
    @PutMapping("/{id}")
    public Team updateTeam(@PathVariable Long id,
                           @Valid @RequestBody Team team) {

        return service.updateTeam(id, team);
    }

    // =========================
    // ADMIN - Delete Team Member
    // =========================

    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/{id}")
    public String deleteTeam(@PathVariable Long id) {

        return service.deleteTeam(id);
    }
}