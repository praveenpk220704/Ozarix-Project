package com.pravix.util;

import com.pravix.entity.Contact;

public class EmailTemplate {

    // ==============================
    // Customer Email
    // ==============================
    public static String customerContactTemplate(String customerName) {

        return """
                <!DOCTYPE html>
                <html>
                <body style="font-family:Arial;background:#f5f5f5;padding:20px;">

                <table width="650" align="center"
                       style="background:white;border-radius:10px;
                       box-shadow:0px 0px 10px rgba(0,0,0,0.2);">

                    <tr>
                        <td style="background:#0d6efd;
                                   color:white;
                                   text-align:center;
                                   padding:20px;">

                            <h1>PRAVIX TECHNOLOGIES</h1>
                            <h3>Building Smart Digital Solutions</h3>

                        </td>
                    </tr>

                    <tr>
                        <td style="padding:30px;">

                            <h2>Hello %s,</h2>

                            <p>
                                Thank you for contacting
                                <b>Pravix Technologies.</b>
                            </p>

                            <p>
                                We have successfully received your request.
                            </p>

                            <p>
                                Our technical team will contact you
                                within <b>24 Hours.</b>
                            </p>

                            <br>

                            <p>
                                Regards,<br>
                                <b>Pravix Technologies</b>
                            </p>

                        </td>
                    </tr>

                    <tr>
                        <td style="background:#eeeeee;
                                   text-align:center;
                                   padding:15px;">

                            © 2026 Pravix Technologies

                        </td>
                    </tr>

                </table>

                </body>
                </html>
                """.formatted(customerName);
    }

    // ==============================
    // Company Notification Email
    // ==============================
    public static String adminContactTemplate(Contact contact) {

        return """
                <!DOCTYPE html>
                <html>
                <body style="font-family:Arial;background:#f5f5f5;padding:20px;">

                <table width="700"
                       align="center"
                       style="background:white;
                              border-radius:10px;
                              box-shadow:0px 0px 10px rgba(0,0,0,0.2);">

                    <tr>

                        <td style="background:#dc3545;
                                   color:white;
                                   text-align:center;
                                   padding:20px;">

                            <h1>NEW CONTACT REQUEST</h1>

                        </td>

                    </tr>

                    <tr>

                        <td style="padding:30px;">

                            <h2>Customer Details</h2>

                            <table border="1"
                                   cellpadding="10"
                                   cellspacing="0"
                                   width="100%%">

                                <tr>
                                    <th align="left">Name</th>
                                    <td>%s</td>
                                </tr>

                                <tr>
                                    <th align="left">Email</th>
                                    <td>%s</td>
                                </tr>

                                <tr>
                                    <th align="left">Phone</th>
                                    <td>%s</td>
                                </tr>

                                <tr>
                                    <th align="left">Service</th>
                                    <td>%s</td>
                                </tr>

                                <tr>
                                    <th align="left">Message</th>
                                    <td>%s</td>
                                </tr>

                            </table>

                        </td>

                    </tr>

                    <tr>

                        <td style="background:#eeeeee;
                                   text-align:center;
                                   padding:15px;">

                            Pravix Technologies Admin Notification

                        </td>

                    </tr>

                </table>

                </body>
                </html>
                """.formatted(
                contact.getName(),
                contact.getEmail(),
                contact.getPhone(),
                contact.getService(),
                contact.getMessage()
        );
    }
}