package com.pravix.Controller;

import com.pravix.dto.FileUploadResponse;
import com.pravix.service.FileUploadService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/upload")
@CrossOrigin("*")
public class FileUploadController {

    @Autowired
    private FileUploadService service;

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping
    public FileUploadResponse upload(
            @RequestParam("file") MultipartFile file) throws Exception {

        return service.uploadFile(file);
    }
}