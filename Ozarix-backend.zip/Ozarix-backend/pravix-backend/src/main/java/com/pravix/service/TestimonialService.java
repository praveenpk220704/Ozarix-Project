package com.pravix.service;

import com.pravix.entity.Testimonial;
import com.pravix.repository.TestimonialRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TestimonialService {

    @Autowired
    private TestimonialRepository repository;

    // Create
    public Testimonial save(Testimonial testimonial) {
        return repository.save(testimonial);
    }

    // Public - Active Testimonials
    public List<Testimonial> getAllActiveTestimonials() {
        return repository.findByActiveTrue();
    }

    // Admin - All Testimonials
    public List<Testimonial> getAllTestimonials() {
        return repository.findAll();
    }

    // Get By Id
    public Testimonial getById(Long id) {
        return repository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Testimonial Not Found"));
    }

    // Update
    public Testimonial update(Long id, Testimonial updated) {

        Testimonial testimonial = getById(id);

        testimonial.setClientName(updated.getClientName());
        testimonial.setCompany(updated.getCompany());
        testimonial.setDesignation(updated.getDesignation());
        testimonial.setRating(updated.getRating());
        testimonial.setMessage(updated.getMessage());
        testimonial.setImage(updated.getImage());
        testimonial.setActive(updated.isActive());

        return repository.save(testimonial);
    }

    // Delete
    public String delete(Long id) {

        Testimonial testimonial = getById(id);

        repository.delete(testimonial);

        return "Testimonial Deleted Successfully";
    }
}