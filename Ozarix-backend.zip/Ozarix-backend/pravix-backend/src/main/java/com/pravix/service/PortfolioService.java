package com.pravix.service;

import com.pravix.entity.Portfolio;
import com.pravix.repository.PortfolioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PortfolioService {

    @Autowired
    private PortfolioRepository repository;

    // Create
    public Portfolio save(Portfolio portfolio) {
        return repository.save(portfolio);
    }

    // Get All
    public List<Portfolio> getAll() {
        return repository.findAll();
    }

    // Get By Id
    public Portfolio getById(Long id) {
        return repository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Portfolio Project Not Found"));
    }

    // Update
    public Portfolio update(Long id, Portfolio updatedPortfolio) {

        Portfolio portfolio = getById(id);

        portfolio.setProjectTitle(updatedPortfolio.getProjectTitle());
        portfolio.setCategory(updatedPortfolio.getCategory());
        portfolio.setDescription(updatedPortfolio.getDescription());
        portfolio.setTechnologies(updatedPortfolio.getTechnologies());
        portfolio.setClientName(updatedPortfolio.getClientName());
        portfolio.setProjectUrl(updatedPortfolio.getProjectUrl());
        portfolio.setGithubUrl(updatedPortfolio.getGithubUrl());
        portfolio.setImageUrl(updatedPortfolio.getImageUrl());
        portfolio.setFeatured(updatedPortfolio.isFeatured());

        return repository.save(portfolio);
    }

    // Delete
    public String delete(Long id) {

        Portfolio portfolio = getById(id);

        repository.delete(portfolio);

        return "Portfolio Project Deleted Successfully";
    }
}