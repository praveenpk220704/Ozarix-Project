package com.pravix;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PravixBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(PravixBackendApplication.class, args);
	}

}
