package com.pravix.Controller;

import com.pravix.entity.Testimonial;
import com.pravix.service.TestimonialService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/testimonial")
@CrossOrigin("*")
public class TestimonialController {

    @Autowired
    private TestimonialService service;

    // ============================
    // PUBLIC APIs
    // ============================

    @GetMapping
    public List<Testimonial> getAllActiveTestimonials() {
        return service.getAllActiveTestimonials();
    }

    @GetMapping("/{id}")
    public Testimonial getById(@PathVariable Long id) {
        return service.getById(id);
    }

    // ============================
    // ADMIN APIs
    // ============================

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/admin")
    public List<Testimonial> getAllTestimonials() {
        return service.getAllTestimonials();
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping
    public Testimonial save(@Valid @RequestBody Testimonial testimonial) {
        return service.save(testimonial);
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PutMapping("/{id}")
    public Testimonial update(@PathVariable Long id,
                              @Valid @RequestBody Testimonial testimonial) {

        return service.update(id, testimonial);
    }

    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/{id}")
    public String delete(@PathVariable Long id) {

        return service.delete(id);
    }
}