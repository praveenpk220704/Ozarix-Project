package com.pravix.Controller;

import com.pravix.dto.EmailRequest;
import com.pravix.service.EmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/email")
@CrossOrigin("*")
public class EmailController {

    @Autowired
    private EmailService emailService;

    @PostMapping("/test")
    public String sendTestMail(@RequestBody EmailRequest request) {

        emailService.sendHtmlEmail(
                request.getEmail(),
                "Pravix Backend Test",
                """
                <html>
                <body>
                    <h2>Hello!</h2>
        
                    <p>
                        This is the first email sent successfully from
                        <b>Pravix Backend</b>.
                    </p>
        
                    <br>
        
                    Regards,<br>
                    Pravix Technologies
        
                </body>
                </html>
                """
        );

        return "Email Sent Successfully";
    }
}