package com.pravix.service;

import com.pravix.entity.Career;
import com.pravix.repository.CareerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Service
public class CareerService {

    @Autowired
    private CareerRepository repository;

    @Autowired
    private FileStorageService fileStorageService;

    // Apply for Job with Resume Upload
    public Career applyCareer(
            String fullName,
            String email,
            String phone,
            String position,
            String experience,
            String coverLetter,
            MultipartFile resumeFile) {

        String fileName = fileStorageService.uploadResume(resumeFile);

        Career career = new Career();

        career.setFullName(fullName);
        career.setEmail(email);
        career.setPhone(phone);
        career.setPosition(position);
        career.setExperience(experience);
        career.setCoverLetter(coverLetter);
        career.setResume(fileName);

        return repository.save(career);
    }

    // Get All Applications
    public List<Career> getAll() {
        return repository.findAll();
    }

    // Get Application By ID
    public Career getById(Long id) {
        return repository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Career Application Not Found"));
    }

    // Update Application
    public Career update(Long id, Career updatedCareer) {

        Career career = getById(id);

        career.setFullName(updatedCareer.getFullName());
        career.setEmail(updatedCareer.getEmail());
        career.setPhone(updatedCareer.getPhone());
        career.setPosition(updatedCareer.getPosition());
        career.setExperience(updatedCareer.getExperience());
        career.setResume(updatedCareer.getResume());
        career.setCoverLetter(updatedCareer.getCoverLetter());
        career.setStatus(updatedCareer.getStatus());

        return repository.save(career);
    }

    // Delete Application
    public String delete(Long id) {

        Career career = getById(id);

        repository.delete(career);

        return "Career Application Deleted Successfully";
    }
}