package com.pravix.Controller;

import com.pravix.entity.Career;
import com.pravix.service.CareerService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/api/career")
@CrossOrigin("*")
public class CareerController {

    @Autowired
    private CareerService service;

    // Public - Apply for Job
    @PostMapping(value = "/apply", consumes = "multipart/form-data")
    public Career apply(
            @RequestParam String fullName,
            @RequestParam String email,
            @RequestParam String phone,
            @RequestParam String position,
            @RequestParam(required = false) String experience,
            @RequestParam(required = false) String coverLetter,
            @RequestParam MultipartFile resume) {

        return service.applyCareer(
                fullName,
                email,
                phone,
                position,
                experience,
                coverLetter,
                resume
        );
    }

    // Admin - View All Applications
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping
    public List<Career> getAll() {
        return service.getAll();
    }

    // Admin - View One Application
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/{id}")
    public Career getById(@PathVariable Long id) {
        return service.getById(id);
    }

    // Admin - Update Application
    @PreAuthorize("hasRole('ADMIN')")
    @PutMapping("/{id}")
    public Career update(@PathVariable Long id,
                         @Valid @RequestBody Career career) {

        return service.update(id, career);
    }

    // Admin - Delete Application
    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/{id}")
    public String delete(@PathVariable Long id) {
        return service.delete(id);
    }
}