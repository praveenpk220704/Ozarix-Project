package com.pravix.service;

import com.pravix.entity.ProjectRequest;
import com.pravix.repository.ProjectRequestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProjectRequestService {

    @Autowired
    private ProjectRequestRepository repository;

    @Autowired
    private EmailService emailService;

    // Create Project Request
    public ProjectRequest save(ProjectRequest request) {

        ProjectRequest savedRequest = repository.save(request);

        String subject = "Project Request Received - Pravix Technologies";

        String body =
                "Hello " + request.getClientName() + ",\n\n" +
                        "Thank you for choosing Pravix Technologies.\n\n" +
                        "We have received your project request successfully.\n\n" +

                        "Project Details\n" +
                        "----------------------------------\n" +
                        "Project Title : " + request.getProjectTitle() + "\n" +
                        "Category      : " + request.getCategory() + "\n" +
                        "Company       : " + request.getCompany() + "\n" +
                        "Budget        : " + request.getBudget() + "\n" +
                        "Deadline      : " + request.getDeadline() + "\n\n" +

                        "Our technical team will review your requirements and contact you within 24 hours.\n\n" +

                        "Thank you for trusting Pravix Technologies.\n\n" +

                        "Regards,\n" +
                        "Pravix Technologies\n" +
                        "Email: pravix.tech@gmail.com";

        emailService.sendHtmlEmail(
                request.getEmail(),
                subject,
                "<html><body><pre>" + body + "</pre></body></html>"
        );

        return savedRequest;
    }

    // Get All Project Requests
    public List<ProjectRequest> getAll() {
        return repository.findAll();
    }

    public ProjectRequest getById(Long id) {

        return repository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Project Request Not Found"));
    }

    // Update Project Request
    public ProjectRequest update(Long id, ProjectRequest updatedRequest) {

        ProjectRequest request = getById(id);

        request.setClientName(updatedRequest.getClientName());
        request.setEmail(updatedRequest.getEmail());
        request.setPhone(updatedRequest.getPhone());
        request.setCompany(updatedRequest.getCompany());
        request.setProjectTitle(updatedRequest.getProjectTitle());
        request.setCategory(updatedRequest.getCategory());
        request.setDescription(updatedRequest.getDescription());
        request.setBudget(updatedRequest.getBudget());
        request.setDeadline(updatedRequest.getDeadline());
        request.setStatus(updatedRequest.getStatus());

        return repository.save(request);
    }

    // Delete Project Request
    public String delete(Long id) {

        ProjectRequest request = getById(id);

        repository.delete(request);

        return "Project Request Deleted Successfully";
    }
}