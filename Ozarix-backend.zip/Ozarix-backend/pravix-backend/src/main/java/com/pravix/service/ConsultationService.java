package com.pravix.service;

import com.pravix.entity.Consultation;
import com.pravix.repository.ConsultationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ConsultationService {

    @Autowired
    private ConsultationRepository repository;

    @Autowired
    private EmailService emailService;

    // Create Consultation
    public Consultation saveConsultation(Consultation consultation) {

        Consultation savedConsultation = repository.save(consultation);

        String subject = "Consultation Booking Confirmed";

        String body =
                "Hello " + consultation.getName() + ",\n\n" +
                        "Thank you for booking a consultation with Pravix Technologies.\n\n" +
                        "We have received your consultation request successfully.\n" +
                        "Our team will contact you shortly to confirm your appointment.\n\n" +
                        "Consultation Details:\n" +
                        "----------------------------------\n" +
                        "Service : " + consultation.getService() + "\n" +
                        "Preferred Date : " + consultation.getPreferredDate() + "\n" +
                        "Preferred Time : " + consultation.getPreferredTime() + "\n" +
                        "Budget : " + consultation.getBudget() + "\n\n" +
                        "Thank you for choosing Pravix Technologies.\n\n" +
                        "Regards,\n" +
                        "Pravix Technologies";

        emailService.sendHtmlEmail(
                consultation.getEmail(),
                subject,
                "<html><body><pre>" + body + "</pre></body></html>"
        );

        return savedConsultation;
    }

    // Get All Consultations
    public List<Consultation> getAllConsultations() {
        return repository.findAll();
    }

    public Consultation getConsultation(Long id) {

        return repository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Consultation not found"));
    }

    // Update Consultation
    public Consultation updateConsultation(Long id, Consultation updated) {

        Consultation consultation = getConsultation(id);

        consultation.setName(updated.getName());
        consultation.setEmail(updated.getEmail());
        consultation.setPhone(updated.getPhone());
        consultation.setService(updated.getService());
        consultation.setPreferredDate(updated.getPreferredDate());
        consultation.setPreferredTime(updated.getPreferredTime());
        consultation.setBudget(updated.getBudget());
        consultation.setMessage(updated.getMessage());
        consultation.setStatus(updated.getStatus());

        return repository.save(consultation);
    }

    // Delete Consultation
    public String deleteConsultation(Long id) {

        Consultation consultation = getConsultation(id);

        repository.delete(consultation);

        return "Consultation Deleted Successfully";
    }
}