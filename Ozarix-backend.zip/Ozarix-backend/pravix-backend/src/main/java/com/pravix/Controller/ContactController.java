package com.pravix.Controller;

import com.pravix.entity.Contact;
import com.pravix.service.ContactService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/contact")
@CrossOrigin("*")
public class ContactController {

    @Autowired
    private ContactService service;

    // Public
    @PostMapping
    public Contact saveContact(@Valid @RequestBody Contact contact) {
        return service.saveContact(contact);
    }

    // ADMIN
    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public List<Contact> getAllContacts() {
        return service.getAllContacts();
    }

    // ADMIN
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/{id}")
    public Contact getContact(@PathVariable Long id) {
        return service.getContactById(id);
    }

    // ADMIN
    @PreAuthorize("hasRole('ADMIN')")
    @PutMapping("/{id}")
    public Contact updateContact(@PathVariable Long id,
                                 @Valid @RequestBody Contact contact) {

        return service.updateContact(id, contact);
    }

    // ADMIN
    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/{id}")
    public String deleteContact(@PathVariable Long id) {

        return service.deleteContact(id);
    }
}