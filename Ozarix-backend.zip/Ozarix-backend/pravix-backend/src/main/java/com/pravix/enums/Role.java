package com.pravix.enums;

public enum Role {
    USER,
    ADMIN
}