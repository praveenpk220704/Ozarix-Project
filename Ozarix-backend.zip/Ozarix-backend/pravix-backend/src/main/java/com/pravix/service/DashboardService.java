package com.pravix.service;

import com.pravix.dto.DashboardResponse;
import com.pravix.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DashboardService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ServiceRepository serviceRepository;

    @Autowired
    private ContactRepository contactRepository;

    @Autowired
    private ConsultationRepository consultationRepository;

    @Autowired
    private ProjectRequestRepository projectRequestRepository;

    public DashboardResponse getDashboard() {

        return new DashboardResponse(

                userRepository.count(),

                serviceRepository.count(),

                contactRepository.count(),

                consultationRepository.count(),

                projectRequestRepository.count()
        );
    }
}