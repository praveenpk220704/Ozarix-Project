package com.pravix.Controller;

import com.pravix.entity.ProjectRequest;
import com.pravix.service.ProjectRequestService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/project-request")
@CrossOrigin("*")
public class ProjectRequestController {

    @Autowired
    private ProjectRequestService service;

    // Public
    @PostMapping
    public ProjectRequest create(@Valid @RequestBody ProjectRequest request) {
        return service.save(request);
    }

    // ADMIN
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping
    public List<ProjectRequest> getAll() {
        return service.getAll();
    }

    // ADMIN
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/{id}")
    public ProjectRequest getById(@PathVariable Long id) {
        return service.getById(id);
    }

    // ADMIN
    @PreAuthorize("hasRole('ADMIN')")
    @PutMapping("/{id}")
    public ProjectRequest update(@PathVariable Long id,
                                 @Valid @RequestBody ProjectRequest request) {
        return service.update(id, request);
    }

    // ADMIN
    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/{id}")
    public String delete(@PathVariable Long id) {
        return service.delete(id);
    }
}