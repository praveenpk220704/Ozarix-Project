package com.pravix.Controller;

import com.pravix.entity.Consultation;
import com.pravix.service.ConsultationService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/consultation")
@CrossOrigin("*")
public class ConsultationController {

    @Autowired
    private ConsultationService service;

    // Public
    @PostMapping
    public Consultation bookConsultation(
            @Valid @RequestBody Consultation consultation) {

        return service.saveConsultation(consultation);
    }

    // ADMIN
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping
    public List<Consultation> getAllConsultations() {
        return service.getAllConsultations();
    }

    // ADMIN
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/{id}")
    public Consultation getConsultation(@PathVariable Long id) {
        return service.getConsultation(id);
    }

    // ADMIN
    @PreAuthorize("hasRole('ADMIN')")
    @PutMapping("/{id}")
    public Consultation updateConsultation(
            @PathVariable Long id,
            @Valid @RequestBody Consultation consultation) {

        return service.updateConsultation(id, consultation);
    }

    // ADMIN
    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/{id}")
    public String deleteConsultation(@PathVariable Long id) {

        return service.deleteConsultation(id);
    }
}