package com.pravix.repository;

import com.pravix.entity.ProjectRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProjectRequestRepository extends JpaRepository<ProjectRequest, Long> {

}