package com.pravix.Controller;

import com.pravix.entity.ServiceEntity;
import com.pravix.service.ServiceService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/services")
@CrossOrigin(origins = "*")
public class ServiceController {

    @Autowired
    private ServiceService service;

    // Create Service
    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping
    public ServiceEntity addService(@Valid @RequestBody ServiceEntity serviceEntity) {
        return service.addService(serviceEntity);
    }

    // Get All Services
    // Public
    @GetMapping
    public List<ServiceEntity> getAllServices() {
        return service.getAllServices();
    }

    // Public
    @GetMapping("/{id}")
    public ServiceEntity getServiceById(@PathVariable Long id) {
        return service.getServiceById(id);
    }
    // Update Service
    @PreAuthorize("hasRole('ADMIN')")
    @PutMapping("/{id}")
    public ServiceEntity updateService(@PathVariable Long id,
                                       @Valid @RequestBody ServiceEntity serviceEntity) {
        return service.updateService(id, serviceEntity);
    }

    // Delete Service
    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/{id}")
    public String deleteService(@PathVariable Long id) {
        return service.deleteService(id);
    }
}