package com.pravix.Controller;

import com.pravix.entity.Portfolio;
import com.pravix.service.PortfolioService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/portfolio")
@CrossOrigin("*")
public class PortfolioController {

    @Autowired
    private PortfolioService service;

    // ADMIN - Create
    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping
    public Portfolio create(@Valid @RequestBody Portfolio portfolio) {
        return service.save(portfolio);
    }

    // PUBLIC - View All
    @GetMapping
    public List<Portfolio> getAll() {
        return service.getAll();
    }

    // PUBLIC - View One
    @GetMapping("/{id}")
    public Portfolio getById(@PathVariable Long id) {
        return service.getById(id);
    }

    // ADMIN - Update
    @PreAuthorize("hasRole('ADMIN')")
    @PutMapping("/{id}")
    public Portfolio update(@PathVariable Long id,
                            @Valid @RequestBody Portfolio portfolio) {
        return service.update(id, portfolio);
    }

    // ADMIN - Delete
    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/{id}")
    public String delete(@PathVariable Long id) {
        return service.delete(id);
    }
}