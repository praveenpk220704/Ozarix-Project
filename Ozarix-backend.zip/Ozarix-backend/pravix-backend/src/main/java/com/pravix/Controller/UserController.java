package com.pravix.Controller;

import com.pravix.dto.LoginRequest;
import com.pravix.dto.LoginResponse;
import com.pravix.dto.RegisterRequest;
import com.pravix.entity.User;
import com.pravix.repository.UserRepository;
import com.pravix.service.UserService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

        import java.util.List;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")
public class UserController {

    @Autowired
    private UserService service;

    @Autowired
    private UserRepository repository;

    // Register
    @PostMapping("/register")
    public String register(@Valid @RequestBody RegisterRequest request) {
        return service.register(request);
    }

    // Login
    @PostMapping("/login")
    public LoginResponse login(@Valid @RequestBody LoginRequest request) {
        return service.login(request);
    }

    // Get All Users (Testing Only)
    @GetMapping("/users")
    public List<User> getAllUsers() {
        return repository.findAll();
    }
}